import React, { useState } from "react";

export const Context = React.createContext();
export function ContextFunc({ children }) {


  const [cart, setCart] = useState(
    JSON.parse(localStorage.getItem("localData")) || []
  );

  const [totalPrice, setTotalPrice] = useState(
    cart.reduce(
      (akk, val) => akk + val.price * val.number,
      0
    )
  );
    

  // let refLc = () => {
  //   setCart(JSON.parse(localStorage.getItem("localData")) || []);
  // };

  // let addCartFunc = (item) => {
  //   if (cart.length === 0) {
  //     localStorage.setItem("localData", JSON.stringify(setCart([...cart, item])));
  //   } else {
  //     JSON.parse(localStorage.getItem("localData")).map((val) =>
  //       val.id === item.id
  //         ? alert("This product has been added to the cart!")
  //         : localStorage.setItem("localData", JSON.stringify(setCart([...cart, item])))
  //     );
  //   }
  //   console.log(cart);
  // };

  // const [data, setData] = useState([{}]);

  // alert("This product has been added to the cart!")
  return (
    <Context.Provider value={{ cart, setCart, totalPrice, setTotalPrice }}>
      {children}
    </Context.Provider>
  );
}
