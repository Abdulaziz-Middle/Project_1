import React, { useContext, useEffect, useState } from "react";

// Imgs
import logo from "../../Imgs/MainImgs/Logo.png";

// MUI
import { Button, IconButton, TextField } from "@mui/material";

// React Icons
import {
  AiOutlineSearch,
  AiOutlineArrowDown,
  AiOutlineArrowUp,
  AiOutlineMenu,
} from "react-icons/ai";
import { MdOutlineMenuOpen } from "react-icons/md";
import { BsBasket3 } from "react-icons/bs";
import { NavLink, useNavigate } from "react-router-dom";
import { Context } from "../../Context";


export function Navbar() {

  let backHome = useNavigate("")

  const [time, setTime] = useState({
    hour: 0,
    minute: 0,
    second: 0,
  });
  useEffect(() => {
    setInterval(() => {
      setTime({
        hour: new Date().getHours(),
        minute: new Date().getMinutes(),
        second: new Date().getSeconds(),
      });
    }, 1000);
  }, []);

  const [open, setOpen] = useState(0);
  function openFunc(id) {
    if (open === 0) {
      setOpen(id);
    } else {
      setOpen(0);
    }
  }
  const [open2, setOpen2] = useState(0);
  function openFunc2(id) {
    if (open2 === 0) {
      setOpen2(id);
    } else {
      setOpen2(0);
    }
  }
  let {cart} = useContext(Context)
  return (
    <div className="Navbar">
      <div className="navText">
        <p>LIMITED OFFER: 30% OFF. Use RABBIT30 at Checkout.</p>
        <p className="navTime">
          {time.hour > 9 ? time.hour : "0" + time.hour} :{" "}
          {time.minute > 9 ? time.minute : "0" + time.minute} :{" "}
          {time.second > 9 ? time.second : "0" + time.second}
        </p>
      </div>
      <div className="navTop">
        <IconButton
          style={{ zIndex: 55 }}
          onClick={() => openFunc2("openModal")}
          id="openModalNav"
        >
          {open2 === "openModal" ? <MdOutlineMenuOpen /> : <AiOutlineMenu />}
        </IconButton>
        <div
          className={
            open2 === "openModal" ? "pageModalNav active" : "pageModalNav"
          }
        >
          {/* <IconButton onClick={()=> openFunc(0)}>X</IconButton> */}
          {/* <NavLink to={"/"}>Home</NavLink> */}
          <NavLink to={"/"}>Home</NavLink>
          <NavLink to={"/categorypage"}>Shop All</NavLink>
          {/* <div
            onClick={() => openFunc(1)}
            className={open === 1 ? "pageCategory active" : "pageCategory"}
          >
            Flower
            {open === 1 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
            <div className={open === 1 ? "navCategory active" : "navCategory"}>
              Lola Siren
            </div>
          </div> */}
          {/* <div
            onClick={() => openFunc(2)}
            className={open === 2 ? "pageCategory active" : "pageCategory"}
          >
            Concentrates
            {open === 2 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
            <div className={open === 2 ? "navCategory active" : "navCategory"}>
              Lola Siren
            </div>
          </div> */}
          {/* <div
            onClick={() => openFunc(3)}
            className={open === 3 ? "pageCategory active" : "pageCategory"}
          >
            Promotions/Bundles
            {open === 3 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
            <div className={open === 3 ? "navCategory active" : "navCategory"}>
              Lola Siren
            </div>
          </div> */}
          {/* <div
            onClick={() => openFunc(4)}
            className={open === 4 ? "pageCategory active" : "pageCategory"}
          >
            Support
            {open === 4 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
            <div className={open === 4 ? "navCategory active" : "navCategory"}>
              Lola Siren
            </div>
          </div> */}
          <NavLink to={"/description"}>Description Page</NavLink>
          <i className="powerBy">Power By Muzaffar | 19.05.2023</i>
        </div>
        <img onClick={()=> backHome("/")} className="navLogoImg" src={logo} alt="logo" />
        <div className="navSearchBox">
          <TextField
            id="searchInputNav"
            variant="outlined"
            color="success"
            placeholder="Search..."
            size="small"
          />
          <IconButton
            size="small"
            color="error"
            style={{ background: `#17AF26` }}
          >
            <AiOutlineSearch color="white" />
          </IconButton>
        </div>
        <div className="navAccount">
          <Button
            style={{ color: `#000`, textTransform: `capitalize` }}
            color="inherit"
          >
            <p className="textYourAccount">Your Account</p>
          </Button>
          <hr />
          <IconButton>
            <NavLink to={"/cartpage"}>
              <div className="navOpenCart" color="inherit">
                <BsBasket3 />
                <p className="cartNumber">{cart.length < 10 ? cart.length : "9+"}</p>
              </div>
            </NavLink>
          </IconButton>
        </div>
      </div>
      <div className="navPagination">
        <NavLink to={"/"}>Home</NavLink>
        <NavLink to={"/categorypage"}>Shop All</NavLink>
        <NavLink to={"/description"}>Description Page</NavLink>
        {/* <div
          onClick={() => openFunc(1)}
          className={open === 1 ? "pageCategory active" : "pageCategory"}
        >
          Flower
          {open === 1 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
          <div className={open === 1 ? "navCategory active" : "navCategory"}>
            <NavLink>Lola Siren</NavLink>
          </div>
        </div> */}
        {/* <NavLink>Edibles</NavLink> */}
        {/* <div
          onClick={() => openFunc(2)}
          className={open === 2 ? "pageCategory active" : "pageCategory"}
        >
          Concentrates
          {open === 2 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
          <div className={open === 2 ? "navCategory active" : "navCategory"}>
            <NavLink>Lola Siren</NavLink>
          </div>
        </div> */}
        {/* <NavLink>Mushrooms</NavLink> */}
        {/* <div
          onClick={() => openFunc(3)}
          className={open === 3 ? "pageCategory active" : "pageCategory"}
        >
          Promotions/Bundles
          {open === 3 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
          <div className={open === 3 ? "navCategory active" : "navCategory"}>
            Lola Siren
          </div>
        </div> */}
        {/* <div
          onClick={() => openFunc(4)}
          className={open === 4 ? "pageCategory active" : "pageCategory"}
        >
          Support
          {open === 4 ? <AiOutlineArrowUp /> : <AiOutlineArrowDown />}
          <div className={open === 4 ? "navCategory active" : "navCategory"}>
            Lola Siren
          </div>
        </div> */}
        {/* <NavLink>Rewards</NavLink>
        <NavLink>Blog</NavLink> */}
      </div>
    </div>
  );
}
