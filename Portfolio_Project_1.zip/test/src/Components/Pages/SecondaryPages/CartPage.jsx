import React, { useContext, useState } from "react";

import { Context } from "../../Context";
// Imgs

import icon1 from "../../Imgs/CartPage/icon1.png";
import icon2 from "../../Imgs/CartPage/icon2.png";
import icon3 from "../../Imgs/CartPage/icon3.png";

import icon4 from "../../Imgs/CartPage/icon4.png";
import icon5 from "../../Imgs/CartPage/icon5.png";
import icon6 from "../../Imgs/CartPage/icon6.png";

import circle from "../../Imgs/CartPage/tick-circle.png";
import point from "../../Imgs/CartPage/point.png";

import statusBar from "../../Imgs/CartPage/Statusbar.png";

import cart1 from "../../Imgs/Home/Footer/img1.png";
import cart2 from "../../Imgs/Home/Footer/img2.png";
import cart3 from "../../Imgs/Home/Footer/img3.png";
import cart4 from "../../Imgs/Home/Footer/img4.png";

import icon from "../../Imgs/CartPage/iconEnd.png";

import { TextField } from "@mui/material";

// Mui
import Switch from "@mui/material/Switch";
import { useNavigate } from "react-router-dom";

import Swal from "sweetalert2";
export function CartPage() {
  let { cart, setCart, totalPrice, setTotalPrice } = useContext(Context);

  let minusFunc = (item) => {
    localStorage.setItem(
      "localData",
      JSON.stringify(
        JSON.parse(localStorage.getItem("localData")).map((val) =>
          val.id === item.id && val.number > 0
            ? { ...val, number: val.number - 1 }
            : val
        )
      )
    );
    setCart(JSON.parse(localStorage.getItem("localData")) || []);
    handleTotalPrice();
  };
  let plusFunc = (item) => {
    localStorage.setItem(
      "localData",
      JSON.stringify(
        JSON.parse(localStorage.getItem("localData")).map((val) =>
          val.id === item.id && val.number < 10
            ? { ...val, number: val.number + 1 }
            : val
        )
      )
    );
    setCart(JSON.parse(localStorage.getItem("localData")) || []);
    handleTotalPrice();
  };

  let card = [
    {
      id: 0,
      name: "Order by 10pm for free next day delivery on Orders overs $100",
      text: "We deliver Monday to Saturday - excluding Holidays",
      img: icon4,
    },
    {
      id: 1,
      name: "Free next day delivery to stores.",
      text: "Home delivery is $4.99 for orders under $100 and is FREE for all orders over $100",
      img: icon5,
    },
    {
      id: 2,
      name: "",
      text: "30 days to return it to us for a refund. We have made returns SO EASY - you can now return your order to a store or send it with FedEx FOR FREE",
      img: icon6,
    },
  ];

  let handleTotalPrice = () => {
    setTotalPrice(
      JSON.parse(localStorage.getItem("localData")).reduce(
        (akk, val) => akk + val.price * val.number,
        0
      )
    );
  };

  let deleteFunc = (val) => {
    localStorage.setItem(
      "localData",
      JSON.stringify(
        JSON.parse(localStorage.getItem("localData")).filter(
          (item) => item.id !== val.id
        )
      )
    );
    setCart(JSON.parse(localStorage.getItem("localData")) || []);
    handleTotalPrice();
  };
  const [checked, setChecked] = React.useState(false);

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  const [cartTab, setCartTab] = useState(1);

  let portal = useNavigate();

  let tabFunc = (id) => {
    if (end === true && id === 3) {
      setCartTab(3);
    } else if (id === 1) {
      setCartTab(1);
    } else if (id === 2 && totalPrice > 0) {
      setCartTab(2);
    } else if (totalPrice === 0) {
      alert("You have not selected a product...");
      setCartTab(1);
    }
    if (end !== true && id !== 1 && id !== 2 && totalPrice !== 0) {
      alert("Fill in all the lines...");
      setCartTab(2);
    }
  };

  const [input, setInput] = useState({
    name: "",
    surname: "",
    country: "",
    region: "",
    region2: "",
    city: "",
    province: "",
    zip: "",
    phone: "",
    email: "",
  });

  let inputFunc = (e) => {
    setInput({ ...input, [e.target.name]: e.target.value });
    if (input.city !== "" && input.province !== "" && input.phone !== "") {
      setEnd(true);
    } else {
      setEnd(false);
    }
  };

  let shopFunc = () => {
    setInput({
      name: "",
      surname: "",
      country: "",
      region: "",
      region2: "",
      city: "",
      province: "",
      zip: "",
      phone: "",
      email: "",
    });
    Swal.fire({
      icon: "success",
      title: "Your order has been accepted!",
      text: "Delivered in 10-20 business days!",
    });
    // Swal.fire({
    //   title: "Delete the products in the cart?",
    //   showDenyButton: true,
    //   showCancelButton: true,
    //   confirmButtonText: "Save",
    //   denyButtonText: `Don't save`,
    // }).then((result) => {
    //   if (result.isConfirmed) {
    //     Swal.fire("Saved!", "", "success");
    //   } else if (result.isDenied) {
    //     setCart([])
    //     Swal.fire("The cart has been cleared!", "", "error");
    //   }
    // });
  };

  const [end, setEnd] = useState(false);

  return (
    <div className="CartPage">
      <div className="ceTop">
        <div onClick={() => tabFunc(1)} className="iconBoxce">
          <img src={cartTab > 1 ? icon : icon1} alt="img" />
          <h1>Shopping Cart</h1>
        </div>
        <hr style={{ background: cartTab > 1 ? `#17af26` : "#9d9ea2" }} />
        <div onClick={() => tabFunc(2)} className="iconBoxce">
          <img src={cartTab > 2 ? icon : icon2} alt="img" />
          <h1>Checkout</h1>
        </div>
        <hr
          style={{ background: cartTab > 2 && end ? `#17af26` : "#9d9ea2" }}
        />
        <div onClick={() => tabFunc(3)} className="iconBoxce">
          <img src={icon3} alt="img" />
          <h1>Order Complete</h1>
        </div>
      </div>
      <div className={cartTab === 1 ? "shoppingCart active" : "shoppingCart"}>
        <div className="leftCe">
          <div className="textCe">
            <h1>Your Cart</h1>
            <p>({cart.length})</p>
          </div>
          <hr />
          <div className="cartBoxce">
            {cart.length > 0 ? (
              cart.map((val, i) => (
                <div key={i} className="boxCart">
                  <button
                    onClick={() => deleteFunc(val)}
                    className="deletCartBtn"
                  >
                    Delete
                  </button>
                  <div className="imgAndNameBoxce">
                    <img src={val.img} alt="img" />
                    <h1>
                      {val.name.length > 25 ? (
                        <div>{val.name.slice(0, 25)}...</div>
                      ) : (
                        val.name
                      )}
                    </h1>
                  </div>
                  <div className="plusMinusBoxce">
                    <button onClick={() => minusFunc(val)}>-</button>
                    <p>{val.number}</p>
                    <button onClick={() => plusFunc(val)}>+</button>
                    <h1>${val.price}.00</h1>
                  </div>
                  <h1 className="totalPriceCe">${val.number * val.price}.00</h1>
                </div>
              ))
            ) : (
              <h1>The products added to the cart are not available!</h1>
            )}
          </div>
          <hr />
          <div className="cePanel">
            <div className="cePanelText">
              <h1>Delivery</h1>
              <h1>Free Returns</h1>
            </div>
            <div className="cardCePanel">
              {card.map((val) => (
                <div key={val.id}>
                  <img src={val.img} alt="img" />
                  <h1>{val.name}</h1>
                  <p>{val.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="rightCe">
          <div className="rightCeTop">
            <div>
              <h1>Subtotal</h1>
              <p>${totalPrice}.00</p>
            </div>
            <div>
              <h1>Discount</h1>
              <p>$0.0</p>
            </div>
            <div>
              <h1>Shipping Costs</h1>
              <p>$50.00</p>
            </div>
          </div>
          <div className="rightCeInput">
            <TextField color="success" placeholder="Coupon code" />
            <button>Apply Coupon</button>
          </div>
          <hr />
          <img src={statusBar} alt="img" />
          <h1>
            Get Free <b style={{ color: "#1A1E26," }}>Shipping</b> for orders
            over <b style={{ color: "red" }}>$100.00</b>{" "}
          </h1>
          <h1 style={{ color: `#1A1E26 !important` }}>Continue Shopping</h1>
          <button
            onClick={() => tabFunc(2)}
            className={totalPrice > 0 ? "active" : ""}
          >
            Checkout <hr /> ${totalPrice}.00
          </button>
          <hr />
          <div className="plastikCarts">
            <h1>SECURE PAYMENTS PROVIDED BY</h1>
            <div>
              <img src={cart1} alt="img" />
              <img src={cart2} alt="img" />
              <img src={cart3} alt="img" />
              <img src={cart4} alt="img" />
            </div>
          </div>
        </div>
      </div>
      <div className={cartTab === 2 ? "checkoutCart active" : "checkoutCart"}>
        <div className="ctLeft">
          <div className="textCe">
            <h1>Your Cart</h1>
            <p>({cart.length})</p>
          </div>
          <hr />
          <div className="inputBoxsCt">
            <div>
              <h1>FIRST NAME*</h1>{" "}
              <input name="name" onChange={inputFunc} type="text" />
            </div>
            <div>
              <h1>FIRST NAME*</h1>{" "}
              <input name="surname" onChange={inputFunc} type="text" />
            </div>
          </div>
          <div className="inputBox1Ct">
            <h1>Country / Region *</h1>
            <input
              name="country"
              type="text"
              onChange={inputFunc}
              placeholder="Singapore"
            />
          </div>
          <div className="inputBox1Ct">
            <h1>Country / Region *</h1>
            <input
              name="region"
              onChange={inputFunc}
              type="text"
              placeholder="House number and street name"
            />
            <input
              onChange={inputFunc}
              name="region2"
              type="text"
              placeholder="Apartment, suite, unit, etc. (optional)"
            />
          </div>
          <div className="inputBox2Ct">
            <div>
              <h1>Town / City *</h1>{" "}
              <input onChange={inputFunc} name="city" type="text" />
            </div>
            <div>
              <h1>Province *</h1>{" "}
              <input onChange={inputFunc} name="province" type="text" />
            </div>
            <div>
              <h1>Postcode / ZIP *</h1>{" "}
              <input onChange={inputFunc} name="zip" type="text" />
            </div>
          </div>
          <div className="inputBoxsCt">
            <div>
              <h1>Phone (optional)</h1>{" "}
              <input name="phone" onChange={inputFunc} type="text" />
            </div>
            <div>
              <h1>Email address *</h1>{" "}
              <input
                type="text"
                onChange={inputFunc}
                name="email"
                placeholder="johndoe@example.com"
              />
            </div>
          </div>
          <hr />
          <div className="defaultAdrresBox">
            <input type="checkbox" />
            Ship to a different Address?
          </div>

          <div className="defaultAdrresBox1">
            SOrder Notes (optional)
            <input
              type="text"
              placeholder="Notes about your order, e.g. special notes for delivery."
            />
          </div>
          <hr />
          <div className="defaultAdrresBox2">
            <h1>What would you like us to do if an Item is out os Stock?</h1>
            <input type="text" placeholder="Contact me (With delay)" />
          </div>
          <hr />
          <div className="defaultAdrresBox3">
            <h1>What would you like us to do if an Item is out os Stock?</h1>
            <input
              type="text"
              placeholder="Notes about your order, e.g. special notes for delivery.  "
            />
          </div>
        </div>
        <div className="ctRight">
          <div className="rightCe">
            <div className="rightCeTop">
              <div>
                <h1>Subtotal</h1>
                <p>${totalPrice}.00</p>
              </div>
              <div>
                <h1>Shipping</h1>
                <p>New York, US</p>
              </div>
              <div>
                <h1>Discount</h1>
                <p>$0.0</p>
              </div>
              <div>
                <h1>Shipping Costs</h1>
                <p>$50.00</p>
              </div>
              <hr />
              <div>
                <h1>Shipping Costs</h1>
                <img src={cart4} alt="" />
              </div>
            </div>
            <div className="rightCeInput">
              <TextField color="success" placeholder="Coupon code" />
              <button>Apply Coupon</button>
            </div>
            <hr />
            <div className="checkBoxCt">
              <input type="checkbox" />
              <h1>
                I confirm that my address is 100% correct and WILL NOT hold Top
                Shelf BC liable if this shipment is sent to an incorrect
                address. *
              </h1>
            </div>
            <div className="checkBoxCt">
              <input type="checkbox" />
              <h1>Sign me up to receive email updates and news (optional)</h1>
            </div>
            <hr />
            <div className="pointBox">
              <div className="left">
                <img src={point} alt="img" />
                <h1>Your point</h1>
                <p>10.850</p>
              </div>
              <Switch
                checked={checked}
                onChange={handleChange}
                inputProps={{ "aria-label": "controlled" }}
                color="success"
              />
            </div>
            <button onClick={() => tabFunc(3)} className={end ? "active" : ""}>
              Place Order <hr /> ${totalPrice}.00
            </button>
            <hr />
            <div className="plastikCarts">
              <h1>SECURE PAYMENTS PROVIDED BY</h1>
              <div>
                <img src={cart1} alt="img" />
                <img src={cart2} alt="img" />
                <img src={cart3} alt="img" />
                <img src={cart4} alt="img" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={cartTab === 3 && end ? "orderCom active" : "orderCom"}>
        <div className="textTopOm">
          <h1>Your Order</h1>
          <p>
            <img src={circle} alt="img" /> Paid
          </p>
        </div>
        <hr />
        {cart.length > 0 ? (
          cart.map((val, i) => (
            <div key={i} className="boxCartCm">
              <div className="mainBoxCm">
                <div className="imgAndNameBoxce">
                  <img src={val.img} alt="img" />
                  <h1>
                    {val.name.length > 25 ? (
                      <div>{val.name.slice(0, 25)}...</div>
                    ) : (
                      val.name
                    )}
                  </h1>
                </div>
                <div id="ordeX" className="plusMinusBoxce">
                  <p>{val.number}x</p>
                  <h1>${val.price}.00</h1>
                </div>
                <h1 id="blackColor" className="totalPriceCe">
                  ${val.number * val.price}.00
                </h1>
              </div>
              <hr />
            </div>
          ))
        ) : (
          <h1>The products added to the cart are not available!</h1>
        )}
        <div className="textBtmOm">
          <h1>TOTAL</h1>
          <p>${totalPrice}.00</p>
        </div>
        <hr />
        <div className="shopNowBottom">
          <div className="left">
            <div>
              <h1>Shipping</h1>
              <p>{input.province}</p>
            </div>
            <div>
              <h1>Shipping Options</h1>
              <p>Same-Day Dispatching</p>
            </div>
            <div>
              <h1>Email Money Transfer</h1>
              <p>Interac</p>
            </div>
          </div>
          <div className="left">
            <div>
              <h1>Subtotal</h1>
              <p>${totalPrice}.00</p>
            </div>
            <div>
              <h1>Discount</h1>
              <p>$0.0</p>
            </div>
            <div>
              <h1>Shipping Costs</h1>
              <p>$50.00</p>
            </div>
            <div>
              <h1>Point</h1>
              <p>${((totalPrice / 100) * 20).toFixed(2)}</p>
            </div>
            <hr />
            <div id="Total">
              <h1>TOTAL</h1>
              <p>${(totalPrice - (totalPrice / 100) * 20).toFixed(2)}</p>
            </div>
            <hr />
          </div>
        </div>
        <hr />
        <div className="webEnd">
          <h1>New Order, Click button bellow</h1>
          <button onClick={shopFunc}>Shop Now</button>
        </div>
      </div>
    </div>
  );
}
