import React, { useContext, useState } from "react";
// Imgs

import icon1 from "../../../../Imgs/Home/Section3/icon1.png";
import icon2 from "../../../../Imgs/Home/Section3/icon2.png";
import icon3 from "../../../../Imgs/Home/Section3/icon3.png";
import icon4 from "../../../../Imgs/Home/Section3/icon4.png";
import icon5 from "../../../../Imgs/Home/Section3/icon5.png";
import icon6 from "../../../../Imgs/Home/Section3/icon6.png";

import card1 from "../../../../Imgs/Home/Section1/imgCard1.png";
import card3 from "../../../../Imgs/Home/Section1/imgCard3.png";

import card3Img1 from "../../../../Imgs/Home/Header/hmImg1.png";
import card3Img2 from "../../../../Imgs/Home/Header/hmImg2.png";

import img1 from "../../../../Imgs/Home/Section3/img1.png";
import img2 from "../../../../Imgs/Home/Section3/img2.png";
import img3 from "../../../../Imgs/Home/Section3/img3.png";

import card4Img1 from "../../../../Imgs/Home/Section3/card4Img1.png";
import card4Img2 from "../../../../Imgs/Home/Section3/card4Img2.png";
import card4Img3 from "../../../../Imgs/Home/Section3/card4Img3.png";

import star from "../../../../Imgs/Home/Section1/startIcon.png";
import { Context } from "../../../../Context";
// import whiteStar from "../../../../Imgs/Home/Section1/whiteStar.png";
export function Section3() {
  const [card, setCard] = useState([
    {
      img: icon1,
      name: "CUSTOMER SERVICE",
      content:
        "Whether it is answering any questions you have before making a purchase, helping out with the buying process itself or taking your feedback under consideration, we are proud to provide high quality customer service that makes you – the customer – the most important person in the transaction.",
    },
    {
      img: icon2,
      name: "SECURITY",
      content:
        "When it comes to security, we only keep what details are necessary for you to have an account with us and make an order. When it comes to shipping your mail order marijuana out, we use only tamper-proof and discrete packaging so then what you’ve purchased is your business only.",
    },
    {
      img: icon3,
      name: "BEST VALUE",
      content:
        "We are continually adjusting what we supply and our prices to ensure that we maintain an optimal balance of affordable and quality for our products. We invest in the best quality strains that we can find and are always on the lookout for new, affordable and high quality weed products.",
    },
    {
      img: icon4,
      name: "DELIVERY INSURANCE",
      content:
        "If your mail order marijuana becomes lost, stolen, or damaged during transit, we will send you a replacement completely free of charge. Free Canada Post Xpress shipping on all orders over $120",
    },
    {
      img: icon5,
      name: "HIGHEST QUALITY",
      content:
        "All of our cannabis products are tested to ensure that they are the highest quality possible. We work with expert suppliers and are always revising what makes a quality cannabis product to ensure that we have only the best available.",
    },
    {
      img: icon6,
      name: "TRUST",
      content:
        "With over 15 years in the weed business, you can rest assured that you will be taken care of. You can guarantee that we have your best interests in mind. Feel free to check out our reviews.",
    },
  ]);
  const [product1, setProduct1] = useState([
    {
      id: 24,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "CONCENTRATES",
      star: "4.2",
      img: card3,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 200,
      number: 0,
    },
    {
      id: 25,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card3Img1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 26,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card3Img2,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 27,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
  ]);

  const [data, setData] = useState([
    {
      img: img1,
      name: "Indica",
      content:
        "This type of cannabis is commonly taken by those who want to sink into a state of total relaxation in every limb. This reduces stress overall and can take your worries and fatigue away. Because of its relaxing effects, it is suggested to use this type of cannabis at night. It is particularly recommended for people who have trouble sleeping, be it due to insomnia, pain or other associated sleep issues.",
    },
    {
      img: img2,
      name: "Sativa",
      content:
        "Contrary to the deep all-body relaxation that comes with the use of indica strains, sativas are known for increasing the feeling of creativity, enhancing focus and lessening anxiety. This is more of a mind-centered high in terms of how and where you will feel the effects. Given its stimulating nature, it is recommended to use this during the day.",
    },
    {
      img: img3,
      name: "Hybrids",
      content:
        "Hybrid strains are just that – they combine the head-focused high effects of sativas with the bodily relaxation of indicas. This is ideal for people who really want to sooth any fatigue and worries while also clearing the mind ready to focus fresh on something new. Hybrids are expertly tailored to result in strains with specific effects. Useful strain vocabulary to familiarize yourself with when it comes to hybrids includes sativa-dominant (full, bodily relaxation), indica-dominant (boosting creativity, increasing mood and lessening anxiety) and balanced (the best of both worlds).",
    },
  ]);
  const [card4, setCard4] = useState([
    {
      name: "12 Mistakes To Avoid When Buying Cannabis Online",
      img: card4Img1,
      content:
        "Buying cannabis online can be a great way to get your hands on the products you need without leaving the comfort of your home. But …",
      data: "January 24, 2023",
    },
    {
      name: "How To Store Cannabis and Keep it Fresh and Potent?",
      img: card4Img2,
      content:
        "Cannabis packaging has advanced dramatically in recent years, whether your state has a medicinal marijuana programme, legal adult-use weed, or both. Most ...",
      data: "January 20, 2023",
    },
    {
      name: "The Ultimate Guide to Checking the Quality of Cannabis – 10 Industry Leading Tips",
      img: card4Img3,
      content:
        "Quality cannabis is a term used to describe cannabis products that meet specific standards of excellence. It is essential to understand what quality cannabis means, …",
      data: "January 19, 2023",
    },
  ]);
  let { cart, setCart } = useContext(Context);
  let addCartFunc = (item) => {
    if (cart.filter((val) => val.id === item.id).length === 0) {
      localStorage.setItem("localData", JSON.stringify([...cart, item]))
      setCart(JSON.parse(localStorage.getItem("localData")) || [])
    } else {
      alert("This product has been added to the cart!");
    }
  };
  // let addCartFunc = (item) => {
  //   if (cart.filter((val) => val.id === item.id).length === 0) {
  //     localStorage.setItem("localData", JSON.stringify([...cart, item]));
  //     setCart(JSON.parse(localStorage.getItem("localData")) || []);
  //   } else {
  //     alert("This product has been added to the cart!");
  //   }
  // };
  return (
    <div className="Section3">
      <div className="mainCardsSec3">
        <div className="sec3Cards1">
          <div className="sec3Cards1Text">
            <h1>
              WHAT MAKES US THE <b>#1</b> ONLINE MARIJUANA DISPENSARY IN CANADA?
            </h1>
            <p>
              When it comes to what makes us the foremost online marijuana
              dispensary in Canada, we could wax lyrical about our positive
              qualities. Instead, to make this information clearer, we’ve
              highlighted the six prioritized features that we feel makes us a
              cut above the rest.
            </p>
          </div>
          <div className="cards1Box">
            {card.map((val, i) => (
              <div key={i} className="card">
                <img src={val.img} alt="img" />
                <h1>{val.name}</h1>
                <p>{val.content}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="sec1Cards3">
          <h1>RECENTLY ADDED</h1>
          <div className="filterBoxCards3">
            <h1>Filter by Interest</h1>
            <div className="sec3Btns">
              <button className="active">Flowers</button>
              <button>Mushrooms</button>
              <button>Concentrate</button>
              <button>Edibles</button>
              <button>Shop All Weed</button>
            </div>
            <button>Show All</button>
          </div>
          <div className="cardsBoxCard3">
            {product1.map((val, i) => (
              <div key={i} className="card3">
                <div className="cardImg">
                  <img src={val.img} alt="img" />
                  <button className="cardSrockBtn">Out Of Stock</button>
                </div>
                <h1 className="cardCategory">{val.category}</h1>
                <div className="cardContet">
                  <h1 className="cardName">{val.name}</h1>
                  <div className="cardClass">
                    <div className="star">
                      <img src={star} alt="img" />
                      {val.star}/5
                      <hr />
                      {val.reviews}
                      <p>Reviews</p>
                    </div>
                    <h1 className="cardComposition">{val.composition}</h1>
                    <div className="priceBox">
                      <p className="salePrice">
                        {val.price - (val.price / 100) * val.sale}$
                      </p>
                      <p className="price">{val.price}$</p>
                    </div>
                  </div>
                  <div className="cardKilo">
                    <p>28g</p>
                    <p>1/2lb</p>
                    <p>1/4lb</p>
                  </div>
                  <button
                    onClick={() => addCartFunc(val)}
                    className="addCartBtn"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        <hr />
        <div className="sec3Cards3">
          {data.map((val, i) => (
            <div key={i} className="sec3Card3">
              <img src={val.img} alt="img" />
              <div className="contentSec3">
                <h1>{val.name}</h1>
                <p>{val.content}</p>
              </div>
              <button>Shop Indica</button>
            </div>
          ))}
        </div>
      </div>
      <div className="sec3Cards4">
        <div className="content">
          <h1>WEED EDUCATION</h1>
          <button>Show All</button>
        </div>
        <hr />
        <div className="cardsSec3">
          {card4.map((val, i) => (
            <div key={i} className="sec3Card4">
              <img src={val.img} alt="img" />
              <div className="sec3Card4Content">
                <b>{val.data}</b>
                <h1>{val.name}</h1>
                <p>{val.content}</p>
              </div>
              <button>Read More</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
